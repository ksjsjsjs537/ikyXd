export default function handler(req, res) {
  return res.status(200).json({
    status: true,
    message: "Hello from your API!",
    author: "Ngadinem yeyey",
  });
}
