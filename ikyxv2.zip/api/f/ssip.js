const axios = require("axios");

async function SSIPGenerator({ text = "", batre = "100", time = "", signal = "4", emoji = "apple", carrier = "" }) {
  try {
    const url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&messageText=${encodeURIComponent(text)}&carrierName=${encodeURIComponent(carrier)}&batteryPercentage=${encodeURIComponent(batre)}&signalStrength=${encodeURIComponent(signal)}&emojiStyle=${encodeURIComponent(emoji)}`;
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return res.data;
  } catch (err) {
    console.error("Error:", err.message);
    return null;
  }
}

module.exports = { SSIPGenerator };